<?php include('connect.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>DevSmash - Bienvenue</title>
	<link rel="stylesheet" type="text/css" href="./slick/slick.css">
	<link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" media="screen and (max-width: 1000px)" href="css/petit.css" type="text/css" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>

	<div align="center">

		<div id="header">
			<img src="img/logo3.png" />
				<div id="btn_menu">
					<span class="glyphicon glyphicon-menu-hamburger"></span>
				</div>
				<div id="btn_menu2">
					<span class="glyphicon glyphicon-menu-hamburger"></span>
				</div>
			<div id="menu">
				<a href="/home"><span class="glyphicon glyphicon-home"></span> Accueil</a>
				<a href="/template"><span class="glyphicon glyphicon-pencil"></span> Template</a>
				<a href="/home"><span class="glyphicon glyphicon-console"></span> Script</a>
				<a href="/home"><span class="glyphicon glyphicon-envelope"></span> Contact</a>
			</div>
		</div>

		<script type="text/javascript" src="script_js/menu.js"></script>

		<div id="slider">
			<div id="contenu_slider">
				<div class="single-item">
					<div>
						<img src="slider/slide1.png">
					</div>
					<div>
						<img src="slider/slide2.png">
					</div>
				</div>
			</div>
		</div>
		<script src="js/jquery.min.js" type="text/javascript"></script>
		<script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript">
			$(document).on('ready', function() {
				$('.single-item').slick({
					autoplay: true,
  					autoplaySpeed: 4000,
				});
			});
		</script>

	</div>