$(document).ready(function(){
	$("#btn_menu2").hide();
	$("#btn_menu").click(function() {
		$("#menu").show();
		$(this).hide();
		$("#btn_menu2").show();
	});
	$("#btn_menu2").click(function() {
		$("#menu").hide();
		$(this).hide();
		$("#btn_menu").show();
	});
});