-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Ven 08 Septembre 2017 à 20:57
-- Version du serveur :  5.5.49-log
-- Version de PHP :  7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `devsmash`
--

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE IF NOT EXISTS `produit` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `type_prod` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `installation` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `avatar` text NOT NULL,
  `prix` varchar(255) NOT NULL,
  `lien_dl` varchar(255) NOT NULL,
  `nb_dl` int(11) NOT NULL,
  `apercu` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`id`, `nom`, `type_prod`, `version`, `installation`, `description`, `avatar`, `prix`, `lien_dl`, `nb_dl`, `apercu`) VALUES
(1, 'Template Basic', 'template', '1.0 BETA', 'facile', 'Voici une template très basic, avec un code source très simple pour la modification surtout si vous débutez dans le domaine du développement web.\r\nElle possède un menu qui utilise du JQuery pour apparaitre et pour disparaitre avec une délai de 0.5s (500ms).\r\nCe site s''adapte sur des petits écrans par contre pour une version mobile, il ne faut pas que le logo tout en haut soit trop grand, sinon cela vous causera des problèmes, ou bien vous pouvez alors directement modifier des valeurs dans le fichier CSS du site.', 'template_basic.png', '0', 'template_basic.zip', 0, 'template_basic.png');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
