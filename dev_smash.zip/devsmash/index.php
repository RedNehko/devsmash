<?php include('header.php'); ?>

	<div align="center">

		<div id="contenu">

			<h2>Bienvenue sur DevSmash</h2>
			<b>DevSmash</b> est un site qui propose des <b>templates</b>, des <b>scripts PHP</b> ainsi que des <b>libraires CSS</b> et tout ça, <b>GRATUITEMENT</b> !<br />
			<br />
			Nous espérons que notre catalogue vous plaît, nous sommes entrain de développer d'autres produits <b>pour vous</b> !<br />

			<h2>Nos outils</h2>
			Nous sommes entrain de développer des outils <b>en ligne</b> qui vous aiderons dans certains scripts !<br />

			<h2>Les new's</h2>
			Pas de nouveautés pour le moment.

		</div>

		<div id="las_produit">
			<img src="img_produit/img_prod.png" class="last_img_prod" />
			<b>PHP Form Security</b><br /><br />
			<b>Script : </b>PHP<br />
			<b>Version du script : </b>1.2 BETA<br /><br />
			<b>Installation : </b>Très facile<br /><br />
			<b>Description : </b> Il s'agit d'un script PHP, pour être plus précis une fonction, qui à pour but de sécuriser les données dans vos formulaires HTML.<br />
			Le script, transforme des caractères spécifique au développement web en d'autres caractères inoffensifs pour votre site.
		</div>

	</div>

<?php include('footer.php'); ?>