<?php
//Pour se connecter à la base de donnée

$host = 'localhost:3306';//nom de votre host
$user = 'root';//nom de l utilisateur de la bdd
$mdp = 'root';//mot de passe de l utilisateur de la bdd
$name_bdd = 'tuto_youtube';//nom de la bdd

//Pour les modification d une ligne dans BDD
$connect = new PDO('mysql:host='.$host.';dbname='.$name_bdd.'',$user,$mdp) or die(mysql_error());
$connect->exec("SET NAMES utf8");
date_default_timezone_set('UTC');

?>