<?php include('connect.php'); ?>
<! DOCTYPE html >
<!DOCTYPE html>
<html>
<head>
	<title>Template Basic - BETA 1.0</title>
	<meta charset="utf-8" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<div align="center">

		<div id="menu_head">
			<span class="glyphicon glyphicon-menu-hamburger" id="menu_off"></span>
			<span class="glyphicon glyphicon-menu-hamburger" id="menu_on"></span>
			<img src="img/logo.png" />
		</div>

		<div id="menu">
			<a href="">Accueil</a>
			<a href="">Ici un lien</a>
		</div>

		<script type="text/javascript">
			$(document).ready(function(){
				var menu_off = $("#menu_off");
				var menu_on = $("#menu_on");
				var menu = $("#menu");
				menu_off.click(function(){
					menu.show(500);
					menu_off.hide();
					menu_on.show();
				});
				menu_on.click(function(){
					menu.hide(500);
					menu_off.show();
					menu_on.hide();
				});
			});
		</script>

	</div>