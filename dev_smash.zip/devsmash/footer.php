	<div align="center">
		<div id="footer">
			&copy; Copyright DevSmash 2017 | Design by Foxtrot<br />
			<i>Tous droits réservés !</i>
		</div>
	</div>

</body>
</html>