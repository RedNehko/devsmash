<?php include('header.php'); ?>

	<div align="center">

		<style type="text/css">
			#contenu {
				min-height: 250px;
			}
		</style>
		<div id="contenu">

			<h2>Voici la liste de nos Templates</h2><br />
				<?php
					$req_tmp = $bdd->query("SELECT * FROM produit WHERE type_prod='template'");
					while($tmp = $req_tmp->fetch()){
						?>
							<img style="float:left;padding-right:7px;width:150px;height:150px;" src="img_produit/<?php echo $tmp['avatar']; ?>" />
							<h3><?php echo $tmp['nom']; ?></h3>
							<b>Installation : </b><?php echo $tmp['installation']; ?><br />
							<b>Prix : </b><?php if($tmp['prix'] == 0){echo "gratuit";}else{echo $tmp['prix'];} ?><br />
							<b>Nombre de téléchargement(s) : </b><?php echo $tmp['nb_dl']; ?><br /><br />
							<a href="">En savoir plus et/ou le télécharger</a><br />
							<hr><br />
						<?php
					}
					$req_tmp->closeCursor();
				?>

		</div>

		<div id="las_produit">
			<!-- ici mettre des avis ? -->
		</div>

	</div>

<?php include('footer.php'); ?>