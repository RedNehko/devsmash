<?php include('header.php'); ?>

	<div align="center">

		<div id="contenu">

			<h2>Accueil <small>Bienvenue à vous tous !</small></h2><br />

			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

			<h2>A propos !</h2><br />
			Cette template a était développée par JenkoXPlay (plus connus sous Foxtrot dans le monde du développement web) !<br />
			Cette template est gratuit merci de bien vouloir le copyright pour le respect en vers le créateur de cette template !

		</div>

	</div>

<?php include('footer.php'); ?>