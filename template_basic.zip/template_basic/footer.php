	<div align="center">
		<div id="copy">
			&copy; Copyright DevSmash 2017 | Design by Foxtrot<br />
			<i>Toute reproduction, même partielle est strictement interdite !</i>
		</div>
	</div>
	
</body>
</html>